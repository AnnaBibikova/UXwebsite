$ErrorActionPreference = 'Stop'
$secure = Read-Host 'Enter your Jira API token (input is hidden)' -AsSecureString
if ($secure.Length -eq 0) { throw 'Token cannot be empty.' }
$encrypted = ConvertFrom-SecureString $secure
$target = Join-Path $PSScriptRoot 'token.dpapi'
[System.IO.File]::WriteAllText($target, $encrypted)
Write-Host "Token saved with Windows DPAPI encryption to $target"
