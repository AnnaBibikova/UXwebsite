import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import { execFileSync } from "node:child_process";
import { fileURLToPath } from "node:url";
import { readFileSync } from "node:fs";
import path from "node:path";
import { z } from "zod";

const serverDir = path.dirname(fileURLToPath(import.meta.url));
try {
  const envFile = readFileSync(path.join(serverDir, ".env"), "utf8").replace(/^\uFEFF/, "");
  for (const line of envFile.split(/\r?\n/)) {
    const entry = line.trim();
    if (!entry || entry.startsWith("#")) continue;
    const match = entry.match(/^([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)$/);
    if (!match || process.env[match[1]] !== undefined) continue;
    let value = match[2].trim();
    if ((value.startsWith("\"") && value.endsWith("\"")) || (value.startsWith("'") && value.endsWith("'"))) value = value.slice(1, -1);
    process.env[match[1]] = value;
  }
} catch {}

const baseUrl = (process.env.JIRA_BASE_URL || "").replace(/\/$/, "");
const email = process.env.JIRA_EMAIL || "";
const tokenPath = path.join(path.dirname(fileURLToPath(import.meta.url)), "token.dpapi");
let token = process.env.JIRA_API_TOKEN || "";
if (!token) {
  try {
    token = execFileSync("powershell.exe", ["-NoProfile", "-NonInteractive", "-Command", `$s = Get-Content -Raw -LiteralPath '${tokenPath.replaceAll("'", "''")}'; $sec = ConvertTo-SecureString $s; $p = [System.Net.NetworkCredential]::new('', $sec).Password; [Console]::Write($p)`], { encoding: "utf8", stdio: ["ignore", "pipe", "ignore"] }).trim();
  } catch {}
}
if (!token) {
  try { token = readFileSync(path.join(path.dirname(fileURLToPath(import.meta.url)), "jira-token.txt"), "utf8").trim(); } catch {}
}
const apiVersion = process.env.JIRA_API_VERSION || "3";
if (!baseUrl || !token) throw new Error("Set JIRA_BASE_URL and JIRA_API_TOKEN before starting the server.");
if (!/^https:\/\//i.test(baseUrl)) throw new Error("JIRA_BASE_URL must use HTTPS.");
if (!/^[a-zA-Z0-9.-]+(?::\d+)?$/.test(new URL(baseUrl).host)) throw new Error("Invalid Jira host.");

const cloud = /(^|\.)atlassian\.net$/i.test(new URL(baseUrl).hostname);
const apiRoot = `${baseUrl}/rest/api/${apiVersion}`;
const auth = cloud
  ? `Basic ${Buffer.from(`${email}:${token}`).toString("base64")}`
  : `Bearer ${token}`;

async function jira(path, query = {}) {
  const url = new URL(`${apiRoot}${path}`);
  for (const [key, value] of Object.entries(query)) {
    if (value !== undefined && value !== null) url.searchParams.set(key, String(value));
  }
  const response = await fetch(url, {
    headers: { Accept: "application/json", Authorization: auth },
    signal: AbortSignal.timeout(20000),
  });
  const body = await response.text();
  if (!response.ok) throw new Error(`Jira API ${response.status}: ${body.slice(0, 1500)}`);
  if (!response.headers.get("content-type")?.includes("json")) throw new Error(`Expected Jira JSON but received ${response.headers.get("content-type") || "an unknown content type"} from ${response.url}. Check that JIRA_BASE_URL is the direct Jira site URL, not a help portal/proxy URL.`);
  return body ? JSON.parse(body) : {};
}

const server = new McpServer({ name: "local-jira", version: "1.0.0" });
server.registerTool("jira_list_projects", {
  description: "List Jira projects visible to the configured account.",
  inputSchema: { limit: z.number().int().min(1).max(100).default(50) },
}, async ({ limit }) => {
  const data = apiVersion === "2"
    ? await jira("/project")
    : await jira("/project/search", { maxResults: limit });
  const projects = Array.isArray(data) ? data.slice(0, limit) : (data.values ?? data);
  return { content: [{ type: "text", text: JSON.stringify(projects, null, 2) }] };
});

server.registerTool("jira_get_issue", {
  description: "Retrieve one Jira issue by key, such as PROJ-123.",
  inputSchema: { issue_key: z.string().min(1).max(50), fields: z.string().optional() },
}, async ({ issue_key, fields }) => {
  const data = await jira(`/issue/${encodeURIComponent(issue_key)}`, { fields });
  return { content: [{ type: "text", text: JSON.stringify(data, null, 2) }] };
});

server.registerTool("jira_search_issues", {
  description: "Search Jira with JQL. Results are limited to 100 issues per call.",
  inputSchema: {
    jql: z.string().min(1).max(2000),
    limit: z.number().int().min(1).max(100).default(25),
    fields: z.array(z.string()).max(50).optional(),
  },
}, async ({ jql, limit, fields }) => {
  const data = await jira("/search", { jql, maxResults: limit, fields: fields?.join(",") });
  return { content: [{ type: "text", text: JSON.stringify(data, null, 2) }] };
});

await server.connect(new StdioServerTransport());
