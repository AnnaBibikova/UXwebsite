# Local Jira MCP server for Codex

A small, read-only MCP server for using Jira from Codex. It provides three tools:

- `jira_list_projects`
- `jira_get_issue`
- `jira_search_issues` (JQL; up to 100 results per call)

The server uses Jira's REST API and stdio transport. It does not create or change Jira data.

## Requirements

- Windows 10/11
- Node.js 20 or newer
- Codex CLI installed and available as `codex`
- A Jira account and an API token or personal access token accepted by your Jira administrator

## 1. Install dependencies

Extract this folder to a stable local path. Open PowerShell in the extracted `jira-mcp` folder and run:

```powershell
npm install
```

## 2. Add your token

Recommended: run the included script from PowerShell:

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\setup-token.ps1
```

The prompt hides your input and saves a Windows DPAPI-encrypted token in `token.dpapi`. That file can only be decrypted by the same Windows account on the same machine. Do not distribute it.

If PowerShell is unavailable, you may create `jira-token.txt` in this folder with only the token as its contents. This is plain text; restrict access to the file and never share it. Both token files are excluded by `.gitignore`.

## 3. Register the MCP server in Codex

Use the direct Jira site URL (the site root, not a `/browse` page or help portal URL). For Jira Data Center, set the REST version supported by your administrator, commonly `2`:

```powershell
codex mcp add jira-local --env JIRA_BASE_URL=https://jira.example.com --env JIRA_API_VERSION=2 -- node "C:\path\to\jira-mcp\server.js"
```

Replace the URL and file path with your own. For Jira Cloud on an `*.atlassian.net` site, use REST API version `3` and include your Atlassian account email:

```powershell
codex mcp add jira-local --env JIRA_BASE_URL=https://example.atlassian.net --env JIRA_API_VERSION=3 --env JIRA_EMAIL=you@example.com -- node "C:\path\to\jira-mcp\server.js"
```

If you need to change an existing registration, remove it first with `codex mcp remove jira-local`, then run the appropriate add command.

Restart Codex after registering the server or changing its configuration. Check the registration with:

```powershell
codex mcp list
```

## 4. Verify access

Ask Codex to list one Jira project or retrieve an issue you can access. The server only returns data visible to the configured Jira account. If authentication fails, verify the direct Jira URL, token type, account permissions, and API version with your Jira administrator.

## Authentication notes

- Jira Data Center instances may accept a Personal Access Token as a Bearer token. Authentication policy varies by organization.
- Jira Cloud at `*.atlassian.net` uses account email plus API token with HTTP Basic authentication.
- Some Cloud organizations use custom domains or scoped tokens with different authentication requirements. This starter does not implement those variants.
- The token is never part of the MCP registration command. The server reads it locally from `token.dpapi`, `jira-token.txt`, or the `JIRA_API_TOKEN` environment variable.

## Troubleshooting

- **SSO HTML or a sign-in redirect:** the configured URL may be a portal, proxy, or login URL. Ask your Jira administrator for the direct Jira site URL and API authentication method.
- **401/403:** check that the token is valid and enabled for REST API use, and that your account has Jira access.
- **404:** confirm the REST API version and endpoint support for your Jira deployment.
- **No tools after setup:** restart Codex and inspect `codex mcp list`.

This package contains no Jira credentials. Never commit or share token files.
