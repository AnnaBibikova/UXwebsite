# Local Jira MCP server for Codex

This package provides read-only Jira tools for Codex: list projects, retrieve an issue, and search issues with JQL. It does not create or modify Jira data.

## Setup

Requirements: Node.js 20 or newer, Codex CLI, and a Jira personal access token accepted by your organization.

1. Extract this folder to a stable local path.
2. Copy `.env.example` to `.env`. Set `JIRA_API_TOKEN` to your token and confirm `JIRA_BASE_URL` is the direct Jira site URL and `JIRA_API_VERSION` is `2` for NOV Jira (for NOV, use `https://support.nov.com`, without `/browse/...`).
3. Keep `.env` local. It is excluded by `.gitignore`; never upload or share the completed file. On macOS/Linux, restrict access with `chmod 600 .env`.
4. In Terminal, from this folder, run `npm install`.
5. Register the local server with Codex CLI:

```sh
codex mcp add jira-local -- node "/absolute/path/to/jira-mcp/server.js"
```

Replace the example path with the full path to this folder's `server.js`. The server reads `.env` from beside that file. Restart Codex, then verify with `codex mcp list`.

## Try it

Ask Codex to list Jira projects you can access or retrieve a ticket you have permission to view. The server only returns data visible to the Jira account configured by the token.

If authentication fails, check that the token is valid for REST API use, the account can access Jira, and `JIRA_BASE_URL` is the direct site URL rather than a sign-in portal. Ask your Jira administrator which token type and API version NOV accepts.

The optional `setup-token.ps1` helper is Windows-only and stores a token protected with Windows DPAPI. macOS and Linux users should use the local `.env` file.
